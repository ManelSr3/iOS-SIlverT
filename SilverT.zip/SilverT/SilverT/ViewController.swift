//
//  ViewController.swift
//  SilverT
//
//  Created by Manel Soler on 12/03/2020.
//  Copyright © 2020 Manel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

